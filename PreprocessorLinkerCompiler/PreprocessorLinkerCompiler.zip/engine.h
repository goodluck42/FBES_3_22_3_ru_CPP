#pragma once

int compute(int a, int b, int c);