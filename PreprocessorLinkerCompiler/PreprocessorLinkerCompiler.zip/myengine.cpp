#include "engine.h"
#include "mymath.h"

int compute(int a, int b, int c)
{
	return add(a, b) + mult(c, a);
}